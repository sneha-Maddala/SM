 package com.cg.ui;
import java.util.Arrays;
import java.util.Scanner;
import com.cg.bean.BeanClass;
import com.cg.service.BankService;
public class BankModule {
	BankService bankServiceObj = new BankService();
	Scanner sc = new Scanner(System.in);
	
	
	public void createAccount() 
	{
	System.out.print("Enter User Name: ");
	String name = sc.next();
	System.out.print("Enter Phone Number: ");
	long mobNo = sc.nextLong();
	long accNo = mobNo;
	BeanClass bankBeanObj = new BeanClass(accNo, name, mobNo);
	System.out.println("Account created with Account Number: " +accNo);
	bankServiceObj.bankAccountCreate(bankBeanObj);
	}
	
	
	public void showBalance()
	{
	System.out.print("Enter Your Account Number: ");
	long accNo = sc.nextLong();
	BeanClass bankBeanShowBalObj = new BeanClass(accNo);
	bankServiceObj.showBalanceSer(bankBeanShowBalObj);
	}
	
	
	public void deposit()
	{
	System.out.print("Enter Your Account Number: ");
	long accNo = sc.nextLong();
	System.out.print("Enter Deposit Amount: ");
	float depAmount = sc.nextFloat();
	BeanClass bankBeanDeptObj = new BeanClass(accNo, depAmount);
	bankServiceObj.depositSer(bankBeanDeptObj);
	}
	
	
	public void withdraw() 
	{
	System.out.print("Enter Your Account Number: ");
	long accNo = sc.nextLong();
	System.out.print("Enter Withdraw Amount: ");
	float withdrawAmount = sc.nextFloat();
	BeanClass bankBeanWithdrawObj = new BeanClass(withdrawAmount, accNo);
	bankServiceObj.withdrawSer(bankBeanWithdrawObj);
	}
	
	
	public void fundTransfer() 
	{ 
	System.out.println("Enter your Account Number: ");
	long sourceAccNo = sc.nextLong();
	System.out.println("Enter Destination Account Number: ");
	long destAccNo = sc.nextLong();
	System.out.println("Enter the Amount to be transfered: "); 
	float transferAmount = sc.nextFloat();
	BeanClass bankBeanFundTransObj = new BeanClass(sourceAccNo, destAccNo, transferAmount);
	bankServiceObj.transferSer(bankBeanFundTransObj);
	String transactions = transferAmount+ " transferred from Account number " +sourceAccNo+ " to " +destAccNo;
	bankBeanFundTransObj = new BeanClass(transactions);
	}
	
	
	public void printTransactions()
	{
	System.out.println(Arrays.toString(BeanClass.transactions));
	}

}