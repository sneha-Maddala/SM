package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.BeanClass;

public class BankDao {

	BeanClass BeanObj;
	HashMap<Long, BeanClass> hm = new HashMap<Long, BeanClass>(); 
	
	public void addCustomer(BeanClass BeanObj)
	{
	this.BeanObj = BeanObj;
	hm.put(BeanObj.getAccNo(), BeanObj); 
	}
	 public HashMap<Long, BeanClass> hm(){  
	return hm;
	 }

}