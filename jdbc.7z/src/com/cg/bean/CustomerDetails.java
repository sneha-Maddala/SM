package com.cg.bean;

public class CustomerDetails {
	
	private String firstName;
	private String lastName;
	private long mobileNum;
	private long aadharNumber;
	private long accountNum;
	private double money;
	private long accountNumber;
	
	public CustomerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerDetails(String fname, String lname, long phnum, long aadharnum, long accountnum, double money) {
		super();
		this.firstName = fname;
		this.lastName = lname;
		this.mobileNum = phnum;
		this.aadharNumber = aadharnum;
		this.accountNum = accountnum;
		this.money = money;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(long mobileNum) {
		this.mobileNum = mobileNum;
	}

	public long getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(long aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public long getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(long accountNum) {
		this.accountNum = accountNum;
	}

	public double getMoney() {
		return money;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "CustomerDetails [firstName=" + firstName + ", lastName=" + lastName + ", mobileNum=" + mobileNum
				+ ", aadharNumber=" + aadharNumber + ", accountNum=" + accountNum + ", money=" + money
				+ ", accountNumber=" + accountNumber + "]";
	}

	

}
