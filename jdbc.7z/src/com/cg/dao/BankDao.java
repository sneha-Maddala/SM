package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.CustomerDetails;
import com.cg.dbutil.DbUtil;



public class BankDao {
	private Connection connection;
	PreparedStatement prepStmt ;
	double accountBalance;
	double accountBalt;

	
	public CustomerDetails save(CustomerDetails c) {
		
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("insert into CustomerDetails values(?,?,?,?,?,?)");
			prepStmt.setString(1, c.getFirstName());
			prepStmt.setString(2, c.getLastName());
			prepStmt.setLong(3, c.getMobileNum());
			prepStmt.setLong(4, c.getAadharNumber());
			prepStmt.setLong(5, c.getAccountNum());
			prepStmt.setDouble(6, c.getMoney());
			int i = prepStmt.executeUpdate();
			if(i>0)
			{
				System.out.println("Your Account number is:"+c.getAccountNumber());
				System.out.println("Account is Successfully created!!!!");
			}
		}
		catch(SQLException e1)
		{
			System.err.println("Something went wrong");
			e1.printStackTrace();
		}
		return null;
	}

	public String showBal(long accnum) {
		PreparedStatement prepStmt;
		connection = DbUtil.getConnection();
		ResultSet rs;
		CustomerDetails c = new CustomerDetails();
		try {
			prepStmt = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt.setLong(1, accnum);
			rs = prepStmt.executeQuery();
			
			while(rs.next())
			{
				try {
				return Long.toString(rs.getLong(1));
				}
				catch(SQLException e1)
				{
					e1.printStackTrace();
				}
			}
		
		}
		catch(SQLException e1)
		{
			System.out.println("No such Account Number");
			e1.printStackTrace();
		}	
		return Double.toString(c.getMoney());
	}

	
	public void deposit(long acnum, double money1) {
		
		
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt.setLong(1, acnum);
			ResultSet rs = prepStmt.executeQuery();
	
			while(rs.next())
			{
				accountBalance = rs.getDouble(1);
				prepStmt = connection.prepareStatement("update CustomerDetails set money = ? where accountnum = ?");
				prepStmt.setDouble(1, accountBalance+money1);
				prepStmt.setLong(2, acnum);
					int i =prepStmt.executeUpdate();
					if(i>0)
					{
						System.out.println("Your Current Balance is: "+(accountBalance+money1));
					}				
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}


	public void withdraw(long acnum1, double money) {
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt.setLong(1, acnum1);
			ResultSet rs = prepStmt.executeQuery();
			while(rs.next())
			{
				accountBalance = rs.getDouble(1);
				if(accountBalance>=money)
				{
					prepStmt = connection.prepareStatement("update CustomerDetails set money = ? where accountnum = ?");
					prepStmt.setDouble(1, accountBalance-money);
					prepStmt.setLong(2, acnum1);
					int i = prepStmt.executeUpdate();
					if(i>0)
					{
						System.out.println("Your Current Balance is: "+(accountBalance-money));
					}
				}
				
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}


	public double transfer(long yaccnum, long raccnum, long amt) {
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt.setLong(1, yaccnum);
			PreparedStatement prepStmt2 = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt2.setLong(1, raccnum);
			ResultSet rs = prepStmt.executeQuery();
			ResultSet rs1 = prepStmt2.executeQuery();
			while(rs.next()&&rs1.next())
			{
				accountBalt=rs1.getDouble(1);
				accountBalance = rs.getDouble(1);
				if(accountBalance >= amt)
				{
					prepStmt = connection.prepareStatement("update CustomerDetails set money = ? where accountnum = ?");
					prepStmt.setDouble(1, accountBalance-amt);
					prepStmt.setLong(2, yaccnum);
					PreparedStatement prepStmt1 = connection.prepareStatement("update CustomerDetails set money = ? where accountnum = ?");
					prepStmt1.setDouble(1, accountBalt+amt);
					prepStmt1.setLong(2, raccnum);
					prepStmt1.executeUpdate();
					int i = prepStmt.executeUpdate();
					if(i>0)
					{
						return accountBalance-amt;
					}
				}
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}	

}
